<?php
	$name=$_POST['name'];
	$roll=$_POST['roll'];
	echo "hello".$namse.$roll;

?>